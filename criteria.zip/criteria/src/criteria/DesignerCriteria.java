/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package criteria;

/**
 *
 * @author ROG
 */
public interface DesignerCriteria {

    public void inputPortopolio(int nilaiPortopolio){
        this.nilaiPortopolio = nilaiPortopolio
    }

    public void inputPrototyping(int nilaiPrototyping){
        this.nilaiPrototyping = nilaiPrototyping
    }

    public void inputCreativity(int nilaiCreativity){
        this.nilaiCreativity = nilaiCreativity
    }
    
    @override
    public String hitungNilai(){
        return(0.2 * super.nilaiPortopolio) + (0.5 * super.nilaiPrototyping) + (0.3 * super.nilaiCreativity);
    }

    public String keterangan(){
        if(this.hitungNilai()>=85)
            return "DITERIMA\nSelamat " +this.nama + "diterima pekerjaan sebagai designer";
        else
            return "COBA LAGI\nMohon maaf " +this.nama + "tidak mendapatkan perkerjaan sebagai designer\n";
    }
    
}
