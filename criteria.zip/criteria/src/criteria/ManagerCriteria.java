/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package criteria;

/**
 *
 * @author ROG
 */
public interface ManagerCriteria {

    public void inputInnovation(int nilaiInnovation){
        this.nilaiInnovation = nilai.Innovation
    }

    public void inputDecisionMaking(int nilaiDecisionMaking){
        this.nilaiDecisionMaking = nilaiDecisionMaking
    }

    public void inputCommunication(int ni){
        
    }
    public String hitungNilai(){
        
    }
    public String keterangan(){
        
    }
    
}
