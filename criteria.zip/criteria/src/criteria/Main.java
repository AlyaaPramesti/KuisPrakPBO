/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package criteria;

import java.util.Scanner;

/**
 *
 * @author ROG
 */
public class Main {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
        Scanner input = new Scanner(System.in);
      
        System.out.println("+----------------------------+");
        System.out.println("|Pelamaran Lowongan Pekerjaan|");
        System.out.println("+----------------------------+");
        System.out.println("Terdapat 3 posisi yang kosong :");
        System.out.println("1. Progammer");
        System.out.println("2. Designer");
        System.out.println("3. Manager");
        System.out.print("Pilih pekerjaan yang dilamar: ");
        int pilih = input.nextInt();
        
        if (pilih == 1){
        System.out.println("=== Formulir Pelamar ===");
        Scanner data = new Scanner(System.in);
        
        System.out.print("Nama lengkap  : ");
        String nama = data.next();
        
        System.out.println("--- Penilaian ---");
        System.out.println("Keterangan : Nilai yang valid berada di antara 0 - 100");
        System.out.print("Nilai Programming Knowledge : ");
        int nilaiPogramming = data.nextInt();
        System.out.print("Nilai Clean Coding : ");
        int nilaiCoding = data.nextInt();
        System.out.print("Nilai Debugging : ");
        int nilaiDebugging = data.nextInt();
        
        ProgammerCriteria program = new Programmer(nama, nilaiProgramming,nilaiCoding,nilaiDebugging);
            do{
                System.out.println("+++ Menu +++");
                System.out.println("1. Tampilkan Hasil");
                System.out.println("2. Ubah Nilai Pelamar");
                System.out.println("3. Keluar");
                System.out.print("Pilih : ");
                int pilihan = input.nextInt();
                
                if(pilihan == 1){
                    System.out.println("Nilai Akhir : " + program.hitungNilai());
                    System.out.println("Keterangan : " + program.keterangan());
                }
                else if (pilihan == 2){
                    System.out.print("Nilai Programming Knowledge : ");
                    program.inputProgramming(input.nextInt());
                    System.out.print("Nilai Clean Coding : ");
                    program.inputCoding(input.nextInt());
                    System.out.print("Nilai Debugging : ");
                    program.inputWawancara(input.nextInt());
                }
                else{
                    break;
                }
            }while(true);
        }
        else if (pilih == 2){
            System.out.println("=== Formulir Pelamar ===");
            Scanner data = new Scanner(System.in);
            System.out.print("Nama lengkap  : ");
            String nama = data.next();
        
            System.out.println(" Nilai Design Portofolio : ");
            int nilaiPortofolio = data.nextInt();
            System.out.println(" Nilai Prototyping : ");
            int nilaiProtoTyping = data.nextInt();
            System.out.println(" Nilai Creativity : ");
            int nilaiCreatiVity = data.nextInt();
            
            DesignerCriteria desain = new Designer(nama, nilaiPortofolio, nilaiProtoTyping, nilaiCreatiVity);
            
            do{
                System.out.println("+++ Menu +++");
                System.out.println("1. Tampilkan Hasil");
                System.out.println("2. Ubah Nilai Pelamar");
                System.out.println("3. Keluar");
                System.out.print("Pilih : ");
                int pilihan = input.nextInt();
                
                if(pilihan == 1){
                    System.out.println("Nilai Akhir : " + desain.hitungNilai());
                    System.out.println("Keterangan : " + desain.keterangan());
                }
                else if (pilihan == 2){
                    System.out.println(" Nilai Design Portofolio : ");
                    desain.inputPortopolio(input.nextInt());
                    System.out.println(" Nilai Prototyping : ");
                    desain.inputPrototyping(input.nextInt());
                    System.out.println(" Nilai Creativity : ");
                    desain.inputCreativity(input.nextInt());
                }
                else{
                    break;
                }
            }while(true);
        }
        else if(pilih == 3) {
            System.out.println("==Formulir Pelamar==");
            Scanner data= new Scanner(System.in);
            System.out.println("Nama Lengkap : ");
            String nama= data.next();
            
            System.out.println(" Nilai innovation : ");
            int nilaiInnovation = data.nextInt();
            System.out.println(" Nilai desicion making : ");
            int nilaiDecisionMaking = data.nextInt();
            System.out.println(" Nilai communication : ");
            int nilaiCommunication = data.nextInt();
            
            ManagerCriteria manager = new ManagerCriteria(nama, nilaiInnovation, nilaiDecisionMaking, nilaiCommunication);
            
            do {
                System.out.println("+++ Menu +++");
                System.out.println("1. Tampilkan Hasil");
                System.out.println("2. Ubah Nilai Pelamar");
                System.out.println("3. Keluar");
                System.out.println("Pilih : ");
                int pilihan = input.nextInt();
                
                if(pilihan == 1){
                    System.out.println("Nilai Akhir : " +manager.hitungNilai());
                    System.out.println("Keterangan : " + manager.keterangan());
                }
                else if(pilihan == 2){
                    System.out.println("Nilai Inovation : ");
                    manager.inputInnovation(input.nextInt());
                    System.out.println("Nilai Decision Making : ");
                    manager.inputDecisionMaking(input.nextInt());
                    System.out.println("Nilai Communication : ");
                    manager.inputCommunication(input.nextInt());
                }
                else {
                    break;
                }
            }while(true);
        }
        else {
            System.out.println("Input Salah!!");
            System.out.println("Silahkan masukkan angka 1-3");
        }
       
        
            }
        }
        
        
        
      
